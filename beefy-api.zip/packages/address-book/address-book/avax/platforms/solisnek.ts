export const solisnek = {
  router: '0xeeee17b45E4d127cFaAAD14e2710489523ADB4d8', // Solidly Router
  ve: '0xeeee3Bf0E550505C0C17a8432065F2f6b9D06350',
  voter: '0xeeee6FA8A6f8F32d76abAb2131f9e8aeb1b0B02B',
  gaugeStaker: '0x158925aC85D216820789Ac5FEc18fF64be5ca89d',
  bifiEthLp: '0xd45c4da6987cc1067E9eE8481D42AbEeD9167689',
} as const;

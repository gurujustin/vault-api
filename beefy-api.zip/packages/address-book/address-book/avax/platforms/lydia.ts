export const lydia = {
  router: '0xFb26525B14048B7BB1F3794F6129176195Db7766',
} as const;

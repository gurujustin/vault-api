export const swapsicle = {
  router: '0xC7f372c62238f6a5b79136A9e5D16A2FD7A3f0F5',
  chef: '0xd3344E9a4Bc67de0dF101CEe5B047fe2dc5AF354',
} as const;

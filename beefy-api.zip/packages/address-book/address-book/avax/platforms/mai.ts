export const mai = {
  chef: '0x7754b08aB3b73021736985e90163aCC68484F54A',
} as const;

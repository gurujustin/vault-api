export const sushi = {
  minichef: '0x3dB01570D97631f69bbb0ba39796865456Cf89A5', // MiniChefV2
  complexRewarderTime: '0x1334c8e873E1cae8467156e2A81d1C8b566B2da1',
  bifiMovrLp: '0xaC726ee53edFAe5f8f4C2c0d611Fd71D58E743bA',
  router: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506'
} as const;

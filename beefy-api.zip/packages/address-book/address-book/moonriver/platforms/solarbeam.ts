export const solarbeam = {
  masterchef: '0xf03b75831397D4695a6b9dDdEEA0E578faa30907', // MiniChefV2
  masterchefV2: '0xA3Dce528195b8D15ea166C623DB197B2C3f8D127',
  masterchefV3: '0x0329867a8c457e9F75e25b0685011291CD30904F',
  router: '0xAA30eF758139ae4a7f798112902Bf6d65612045f', // UniswapV2Router02
} as const;

export const finn = {
  masterchef: '0x1f4b7660b6AdC3943b5038e3426B33c1c0e343E6', // MasterChef
  router: '0x2d4e873f9Ab279da9f1bb2c532d4F06f67755b77', // UniswapV2Router02
} as const;

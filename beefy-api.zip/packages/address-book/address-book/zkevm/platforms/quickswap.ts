export const quickswap = {
  router: '0xF6Ad3CcF71Abb3E12beCf6b3D2a74C963859ADCd', // UniswapV2Router02
  minichef: '0x1e2D8f84605D32a2CBf302E30bFd2387bAdF35dD',
} as const;

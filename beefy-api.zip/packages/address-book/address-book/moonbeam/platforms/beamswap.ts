export const beamswap = {
  router: '0x96b244391D98B62D19aE89b1A4dCcf0fc56970C7', // UniswapV2Router02
  masterchef: '0xC6ca172FC8BDB803c5e12731109744fb0200587b',
  bifiGlmrLp: '0x321e45B7134b5Ed52129027F1743c8E71DA0A339',
} as const;

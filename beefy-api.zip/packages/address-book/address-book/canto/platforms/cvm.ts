export const cvm = {
  router: '0x2c8F86334552d062A0d7465C7f524eff15AB046c',
  voter: '0xd5FA5bfd83ea4A088a3A28E12AD6494750aC7B8c',
} as const;

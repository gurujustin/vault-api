export const equalizer = {
  router: '0x2F87Bf58D5A9b2eFadE55Cdbd46153a0902be6FA',
  voter: '0x46ABb88Ae1F2a35eA559925D99Fdc5441b592687',
};

export const bvm = {
  router: '0xE11b93B61f6291d35c5a2beA0A9fF169080160cF',
  voter: '0xab9B68c9e53c94D7c0949FB909E80e4a29F9134A',
} as const;

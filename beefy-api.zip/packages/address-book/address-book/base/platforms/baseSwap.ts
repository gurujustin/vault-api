export const baseSwap = {
  router: '0x8DFAf055e21B16302DBf00815e5b4d9b6042a4Df',
  chef: '0x2B0A43DCcBD7d42c18F6A83F86D1a19fA58d541A',
} as const;

export const solace = {
  rewards: '0x501ace3D42f9c8723B108D4fBE29989060a91411',
  xSolace: '0x501Ace47c5b0C2099C4464f681c3fa2ECD3146C1',
} as const;

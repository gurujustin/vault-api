export const equilibre = {
  router: '0xA7544C409d772944017BB95B99484B6E0d7B6388',
  voter: '0x4eB2B9768da9Ea26E3aBe605c9040bC12F236a59',
  bifiKavaLp: '0xf96b58442cCb7D1f0889efb5120B428e3DD56C6f',
} as const;

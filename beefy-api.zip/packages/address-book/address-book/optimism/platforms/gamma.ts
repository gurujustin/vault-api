export const gamma = {
  minichef: '0xC7846d1bc4d8bcF7c45a7c998b77cE9B3c904365',
} as const;

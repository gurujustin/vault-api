export const sonne = {
  comptroller: '0x60CF091cD3f50420d50fD7f707414d0DF4751C58',
} as const;

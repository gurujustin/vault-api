export const polysage = {
  masterchef: '0x0451b4893e4a77E7Eec3B25E816ed7FFeA1EBA68',
  timelock: '0xc8391D2ADF3969f2ecea18e69Af6Ca88abD452cb',
} as const;

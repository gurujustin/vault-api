export default {
  chef: '0x574Fe4E8120C4Da1741b5Fd45584de7A5b521F0F',
  chef2: '0x0635AF5ab29Fc7bbA007B8cebAD27b7A3d3D1958',
  chef3: '0xcC54AfCeCD0d89e0B2db58f5d9e58468E7aD20dc',
} as const;

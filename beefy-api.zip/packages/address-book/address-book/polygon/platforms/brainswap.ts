export const brainswap = {
  masterchef: '0x616CAFA10C2EE31B2da90d9511C92d84bA3F4Fc7',
} as const;

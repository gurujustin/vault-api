export const apeswap = {
  minichef: '0x54aff400858Dcac39797a81894D9920f16972D1D',
  router: '0xC0788A3aD43d79aa53B09c2EaCc313A787d1d607',
  complexRewarderTime: '0x1F234B1b83e21Cb5e2b99b4E498fe70Ef2d6e3bf',
} as const;

export const stargate = {
  masterchef: '0x8731d54E9D02c286767d56ac03e8037C07e01e98',
  router: '0x45A01E4e04F14f7A4a6702c74187c5F6222033cd',
} as const;

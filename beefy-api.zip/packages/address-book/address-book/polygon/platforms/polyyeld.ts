export const polyyeld = {
  masterchef: '0x2DC11B394BD0f1CC6AC0a269cfe3CC0b333601B4',
} as const;

export const polyyeld_xyeld = {
  masterchef: '0x54aC698DbA046247B8D081774005A434f03d329D',
} as const;

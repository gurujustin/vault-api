export const dystopia = {
  router: '0xbE75Dd16D029c6B32B7aD57A0FD9C1c20Dd2862e', // Solidly Router
  ve: '0x060fa7aD32C510F12550c7a967999810dafC5697',
  voter: '0x649BdF58B09A0Cd4Ac848b42c4B5e1390A72A49A',
  gaugeStaker: '0x2b25fc2e80C3f4A7983306fFC72d95a553f59C9d',
} as const;

export const chainlink = {
  VRFCoordinator: '0x3d2341ADb2D31f1c5530cDC622016af293177AE0',
} as const;

export const quickswap = {
  router: '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff', // UniswapV2Router02
  minichef: '0x20ec0d06F447d550fC6edee42121bc8C1817b97D',
} as const;

export default {
  chef: '0x4e22399070aD5aD7f7BEb7d3A7b543e8EcBf1d85',
  router: '0x5C6EC38fb0e2609672BDf628B1fD605A523E5923',
} as const;

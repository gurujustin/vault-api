export const synapse = {
  minichef: '0xd10eF2A513cEE0Db54E959eF16cAc711470B62cF',
} as const;

export const solidly = {
  router: '0x77784f96C936042A3ADB1dD29C91a55EB2A4219f',
  voter: '0x777034fEF3CCBed74536Ea1002faec9620deAe0A',
  bifiEthLp: '0x0346638feF4694629425336c3297Bd0537fa7b43',
} as const;

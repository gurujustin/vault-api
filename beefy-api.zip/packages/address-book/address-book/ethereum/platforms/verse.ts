export const verse = {
  router: '0xB4B0ea46Fe0E9e8EAB4aFb765b527739F2718671',
} as const;

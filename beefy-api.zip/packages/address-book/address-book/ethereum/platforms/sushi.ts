export const sushi = {
  masterchef: '0xc2EdaD668740f1aA35E4D8f227fB8E17dcA888Cd',
  masterchefV2: '0xEF0881eC094552b2e128Cf945EF17a6752B4Ec5d', // MiniChefV2
  router: '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F',
} as const;

export const gamma = {
  minichef: '0x40a3E5778f66835265602f92D507AeC708c2C0AD',
} as const;

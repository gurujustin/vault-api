export const tombswap = {
  router: '0x6D0176C5ea1e44b08D3dd001b0784cE42F47a3A7',
  masterchef: '0xcc0a87F7e7c693042a9Cc703661F5060c80ACb43',
} as const;

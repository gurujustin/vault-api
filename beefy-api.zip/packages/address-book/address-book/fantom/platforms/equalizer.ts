export const equalizer = {
  oldRouter: '0x1A05EB736873485655F29a37DEf8a0AA87F5a447',
  router: '0x2aa07920E4ecb4ea8C801D9DFEce63875623B285',
  voter: '0xE3D1A117dF7DCaC2eB0AC8219341bAd92f18dAC1',
  oldVoter: '0x4bebEB8188aEF8287f9a7d1E4f01d76cBE060d5b',
} as const;

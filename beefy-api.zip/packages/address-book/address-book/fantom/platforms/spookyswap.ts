export const spookyswap = {
  router: '0xF491e7B69E4244ad4002BC14e878a34207E38c29',
  masterchef: '0x2b2929E785374c651a81A63878Ab22742656DcDd',
  masterchefV2: '0x18b4f774fdC7BF685daeeF66c2990b1dDd9ea6aD',
  masterchefV3: '0x9C9C920E51778c4ABF727b8Bb223e78132F00aA4',
  wftmBifiLp: '0x1656728af3a14e1319F030Dc147fAbf6f627059e',
} as const;

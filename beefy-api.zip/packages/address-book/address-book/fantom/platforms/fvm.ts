export const fvm = {
  router: '0x2E14B53E2cB669f3A974CeaF6C735e134F3Aa9BC',
  voter: '0xc9Ea7A2337f27935Cd3ccFB2f725B0428e731FBF',
} as const;

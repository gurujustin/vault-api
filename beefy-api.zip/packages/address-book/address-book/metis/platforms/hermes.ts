export const hermes = {
  router: '0x2d4F788fDb262a25161Aa6D6e8e1f18458da8441',
} as const;

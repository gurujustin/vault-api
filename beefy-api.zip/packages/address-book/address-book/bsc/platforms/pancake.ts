export const pancake = {
  masterchefV2: '0xa5f8C5Dbd5F286960b9d90548680aE5ebFf07652',
  masterchef: '0x73feaa1eE314F8c655E354234017bE2193C9E24E',
  router: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
  oldRouter: '0x05fF2B0DB69458A0750badebc4f9e13aDd608C7F', // For historical reasons only, shouldn't use this for anything new
} as const;

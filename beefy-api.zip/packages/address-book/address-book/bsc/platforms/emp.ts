export const emp = {
  rewardpool: '0x97a68a7949EE30849D273b0c4450314ae26235b1',
  router: '0x10ED43C718714eb63d5aA57B78B54704E256024E', // PancakeSwap
} as const;

export const swapfish = {
  minichef: '0x671eFBa3F6874485cC39535fa7b525fe764985e9',
  router: '0x33141e87ad2DFae5FBd12Ed6e61Fa2374aAeD029',
} as const;

export const cone = {
  router: '0xbf1fc29668e5f5Eaa819948599c9Ac1B1E03E75F', // Solidly Router
  ve: '0xd0C1378c177E961D96c06b0E8F6E7841476C81Ef',
  voter: '0xC3B5d80E4c094B17603Ea8Bb15d2D31ff5954aAE',
  gaugeStaker: '0xA13b6c3A855d9fd084d0678cAcb8230B78416F1A',
} as const;

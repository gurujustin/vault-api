export const bolide = {
  masterchef: '0x3782C47E62b13d579fe748946AEf7142B45B2cf7',
  router: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
} as const;

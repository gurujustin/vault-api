export const ellipsis = {
  multiFeeDistribution: '0x4076CC26EFeE47825917D0feC3A79d0bB9a6bB5c',
} as const;

export const ooe = {
  router: '0xBeB43fbb2f7AEA8AC904975816BB1b4cA9f4D9c5',
} as const;

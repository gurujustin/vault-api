export const babyswap = {
  masterchef: '0xdfAa0e08e357dB0153927C7EaBB492d1F60aC730',
  router: '0x325E343f1dE602396E256B67eFd1F61C3A6B38Bd',
} as const;

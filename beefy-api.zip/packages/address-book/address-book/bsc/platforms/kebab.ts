export const kebab = {
  masterchef: '0x76FCeffFcf5325c6156cA89639b17464ea833ECd',
  smartchef: '0xcbeA91d99993ACF38F9Aabff1aF961b85224DC07',
} as const;

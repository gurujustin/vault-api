export const mdex = {
  masterchef: '0xc48FE252Aa631017dF253578B1405ea399728A50',
  router: '0x7DAe51BD3E3376B8c7c4900E9107f12Be3AF1bA8',
} as const;

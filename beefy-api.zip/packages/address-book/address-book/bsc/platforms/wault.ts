export const wault = {
  masterchef: '0x22fB2663C7ca71Adc2cc99481C77Aaf21E152e2D',
  router: '0xD48745E39BbED146eEC15b79cBF964884F9877c2',
  factory: '0xB42E3FE71b7E0673335b3331B3e1053BD9822570',
} as const;

export const bakery = {
  masterchef: '0x20eC291bB8459b6145317E7126532CE7EcE5056f',
  router: '0xCDe540d7eAFE93aC5fE6233Bee57E1270D3E330F',
} as const;

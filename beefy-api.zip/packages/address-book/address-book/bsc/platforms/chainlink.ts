export const chainlink = {
  VRFCoordinator: '0x747973a5A2a4Ae1D3a8fDF5479f1514F65Db9C31',
} as const;

export const arbidex = {
  router: '0x3E48298A5Fe88E4d62985DFf65Dee39a25914975',
  chef: '0xd2bcFd6b84E778D2DE5Bb6A167EcBBef5D053A06',
} as const;

export const bunni = {
  lens: '0x7683AAEBD54d1377c251840863c53b89c50BE059',
} as const;

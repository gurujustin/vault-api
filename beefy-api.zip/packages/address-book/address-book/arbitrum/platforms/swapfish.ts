export const swapfish = {
  minichef: '0x33141e87ad2DFae5FBd12Ed6e61Fa2374aAeD029',
  router: '0xcDAeC65495Fa5c0545c5a405224214e3594f30d8',
} as const;

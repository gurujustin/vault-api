export const chronos = {
  router: '0xE708aA9E887980750C040a6A2Cb901c37Aa34f3b',
  voter: '0xC72b5C6D2C33063E89a50B2F77C99193aE6cEe6c',
  bifiEthLp: '0x04c106eddDBe89f2Ed983f52020F33D126fA544b',
} as const;

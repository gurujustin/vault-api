export const vesync = {
  router: '0x6C31035D62541ceba2Ac587ea09891d1645D6D07',
  voter: '0xca9c5032D9C72A5028cC760Fd0Cbb45798e68705',
  bifiEthLp: '0xF25ffca3742c66d4729f804e1B1385cE9ed55921',
} as const;

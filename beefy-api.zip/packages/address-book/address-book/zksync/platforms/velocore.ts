export const velocore = {
  router: '0x46dbd39e26a56778d88507d7aEC6967108C0BD36',
  voter: '0xe09A60FAe6d77658b9767A70e2f361b46Dd3f16A',
  bifiEthLp: '0x487b6645068E49Ad8cA8c082327DaB1F4Dc2ECbf',
} as const;

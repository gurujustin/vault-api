export const dracula = {
  router: '0x4D88434eDc8B7fFe215ec598C2290CdC6f58d12D',
  voter: '0x56A209955df2C74bFde45b335D4C46148652791d',
} as const;

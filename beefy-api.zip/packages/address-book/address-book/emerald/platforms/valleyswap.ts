export const valleyswap = {
  router: '0x7C0b0a525fc6A2caDf7AE37198119025C6feA28a',
  masterchef: '0xaE0aF27df228ACd8BA91AF0c917a31A9a681A097',
} as const;

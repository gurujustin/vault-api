export const yuzu = {
  router: '0x250d48C5E78f1E85F7AB07FEC61E93ba703aE668', // UniswapV2Router02
  masterchefExt: '0x8D9cC9ee11AAf865913dEeC939eEb2DC7838ab7B',
  masterchef: '0xB759803Ee7087559EB601a4939c2d5da7668385a',
  swapMining: '0xe63BBe4ef29BFFc40Fa6aE337ca2E532C9A30224',
} as const;

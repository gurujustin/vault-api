export const voltage = {
  router: '0xE3F85aAd0c8DD7337427B9dF5d0fB741d65EEEB5', // VoltageRouter
  masterchef: '0xE3e184a7b75D0Ae6E17B58F5283b91B4E0A2604F',
  bifiFuseLp: '0xbD8923A4028c5D6b6B8698ad4342104302611914',
} as const;

export const crona = {
  masterchef: '0x77ea4a4cF9F77A034E4291E8f457Af7772c2B254',
  router: '0xcd7d16fB918511BF7269eC4f48d61D79Fb26f918', // UniswapV2Router02
} as const;

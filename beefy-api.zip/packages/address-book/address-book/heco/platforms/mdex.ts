export const mdex = {
  router: '0xED7d5F38C79115ca12fe6C0041abb22F0A06C300',
  usdtBifiLp: '0xe6F7b06ad8B93A21f78E4aCD59f2dac169eA704B',
} as const;

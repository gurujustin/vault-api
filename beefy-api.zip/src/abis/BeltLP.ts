const BeltLPAbi = [
  {
    stateMutability: 'view',
    type: 'function',
    name: 'get_virtual_price',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
] as const;

export default BeltLPAbi;
